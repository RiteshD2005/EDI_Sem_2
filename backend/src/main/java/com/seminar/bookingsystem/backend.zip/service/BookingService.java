package com.seminar.bookingsystem.service;

import com.seminar.bookingsystem.model.Booking;
import com.seminar.bookingsystem.model.User;
import com.seminar.bookingsystem.repository.BookingRepository;
import com.seminar.bookingsystem.repository.HallsRepository;
import com.seminar.bookingsystem.repository.UserRepository;
import com.seminar.bookingsystem.exception.*;

import org.springframework.stereotype.Service;

import com.seminar.bookingsystem.dto.BookingRequest;
import com.seminar.bookingsystem.model.Hall;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.Comparator;
import java.util.HashMap;

@Service
public class BookingService {

        private final BookingRepository bookingRepository;
        private final UserRepository userRepository;
        private final HallsRepository hallsRepository; // ✅ add this
        private final EmailService emailService;

        public BookingService(
                        BookingRepository bookingRepository,
                        UserRepository userRepository,
                        HallsRepository hallsRepository, // ✅ inject
                        EmailService emailService) {
                this.bookingRepository = bookingRepository;
                this.userRepository = userRepository;
                this.hallsRepository = hallsRepository; // ✅ assign
                this.emailService = emailService;
        }

        public List<Booking> getUserBookings(String email) {

                User user = userRepository.findByEmail(email)
                                .orElseThrow(() -> new RuntimeException("User not found"));

                return bookingRepository.findByUserOrderByCreatedAtDesc(user);
        }

        public List<Booking> getAllBookings() {
                return bookingRepository.findAll();
        }

        @Transactional
        public Booking approveBooking(Long id, String adminEmail) {

                Booking booking = bookingRepository.findById(id)
                                .orElseThrow(() -> new RuntimeException("Booking not found"));

                if (booking.getStatus() != Booking.Status.PENDING) {
                        throw new RuntimeException("Only pending bookings can be approved");
                }

                // 🔥 CHECK COLLISION AGAIN
                List<Booking> overlapping = bookingRepository
                                .findOverlappingBookings(
                                                booking.getHall(),
                                                Booking.Status.APPROVED,
                                                booking.getStartTime(),
                                                booking.getEndTime());

                if (!overlapping.isEmpty()) {
                        throw new ConflictException("Hall already booked for this time slot");
                }

                User admin = userRepository.findByEmail(adminEmail)
                                .orElseThrow(() -> new RuntimeException("Admin not found"));

                booking.setStatus(Booking.Status.APPROVED);
                booking.setApprovedBy(admin);
                booking.setApproved_at(LocalDateTime.now());

                emailService.sendEmail(
                                booking.getUser().getEmail(),
                                "✅ Booking Approved",
                                "Hello,\n\nYour booking for '" + booking.getEvent_title() + "' has been APPROVED.\n\n" +
                                                "Date: " + booking.getStartTime().toLocalDate() + "\n" +
                                                "Time: " + booking.getStartTime().toLocalTime() + " - "
                                                + booking.getEndTime().toLocalTime() + "\n" +
                                                "Hall: " + booking.getHall().getName() + "\n\n" +
                                                "Regards,\nAdmin");

                return bookingRepository.save(booking);
        }

        @Transactional
        public Booking rejectBooking(Long id, String adminEmail, String note) {

                Booking booking = bookingRepository.findById(id)
                                .orElseThrow(() -> new RuntimeException("Booking not found"));

                if (booking.getStatus() != Booking.Status.PENDING) {
                        throw new RuntimeException("Only pending bookings can be rejected");
                }

                User admin = userRepository.findByEmail(adminEmail)
                                .orElseThrow(() -> new RuntimeException("Admin not found"));

                booking.setStatus(Booking.Status.REJECTED);
                booking.setAdmin_note(note);
                booking.setApprovedBy(admin);
                booking.setApproved_at(java.time.LocalDateTime.now());
                emailService.sendEmail(
                                booking.getUser().getEmail(),
                                "❌ Booking Rejected",
                                "Hello,\n\nYour booking for '" + booking.getEvent_title()
                                                + "' has been REJECTED.\n\n Do check on the application. \n\n" +
                                                "Reason: " + (note != null ? note : "Not specified") + "\n\n" +
                                                "Regards,\nAdmin");

                return bookingRepository.save(booking);
        }

        @Transactional
        public Booking createBooking(String email, BookingRequest request) {

                User user = userRepository.findByEmail(email)
                                .orElseThrow(() -> new RuntimeException("User not found"));

                if (user.getRole() == User.Role.STUDENT) {
                        if (request.getCoordinatorName() == null || request.getCoordinatorName().isEmpty()
                                        || request.getCoordinatorPhone() == null
                                        || request.getCoordinatorPhone().isEmpty()) {

                                throw new RuntimeException("Coordinator details required for students");
                        }
                }

                // ✅ use injected repository
                Hall hall = hallsRepository.findById(request.getHallId())
                                .orElseThrow(() -> new RuntimeException("Hall not found"));

                // Combine eventDate and startTime/endTime to LocalDateTime
                LocalDateTime startDateTime = LocalDateTime.of(request.getEventDate(), request.getStartTime());
                LocalDateTime endDateTime = LocalDateTime.of(request.getEventDate(), request.getEndTime());

                // Use LocalDateTime for repository and entity
                List<Booking> overlapping = bookingRepository
                                .findOverlappingBookings(
                                                hall,
                                                Booking.Status.APPROVED,
                                                startDateTime,
                                                endDateTime);

                if (!overlapping.isEmpty()) {
                        throw new RuntimeException("Hall already booked in this time range");
                }

                Booking booking = new Booking();

                booking.setUser(user);
                booking.setHall(hall);
                booking.setStartTime(startDateTime);
                booking.setEndTime(endDateTime);
                booking.setContactPhone(request.getContactPhone());
                booking.setCoordinatorName(request.getCoordinatorName());
                booking.setCoordinatorPhone(request.getCoordinatorPhone());

                // Set timeRange for TSRANGE column
                // booking.setTimeRange("[" + startDateTime + "," + endDateTime + ")");

                booking.setClub_name(request.getClubName());
                booking.setDesignation(request.getDesignation());
                booking.setEvent_type(request.getEventType());
                booking.setEvent_title(request.getEventTitle());

                booking.setDescription(request.getEventDescription());
                booking.setResources_needed(request.getResourcesNeeded());

                booking.setStudent_count(request.getStudentStrength());
                booking.setStatus(Booking.Status.PENDING);

                return bookingRepository.save(booking);
        }

        public List<Map<String, Object>> getDaySlots(Long hallId, LocalDate date) {

                Hall hall = hallsRepository.findById(hallId)
                                .orElseThrow(() -> new RuntimeException("Hall not found"));

                LocalDateTime startOfDay = date.atStartOfDay();
                LocalDateTime endOfDay = date.atTime(23, 59);

                List<Booking> bookings = bookingRepository
                                .findByHallAndStatusAndStartTimeBetween(
                                                hall,
                                                Booking.Status.APPROVED,
                                                startOfDay,
                                                endOfDay);

                // Sort by time
                bookings.sort(Comparator.comparing(Booking::getStartTime));

                List<Map<String, Object>> slots = new ArrayList<>();

                LocalTime startDay = LocalTime.of(8, 0);
                LocalTime endDay = LocalTime.of(18, 0);

                LocalTime current = startDay;

                for (Booking b : bookings) {

                        LocalTime bookingStart = b.getStartTime().toLocalTime();
                        LocalTime bookingEnd = b.getEndTime().toLocalTime();

                        // Free slot before booking
                        if (current.isBefore(bookingStart)) {
                                slots.add(Map.of(
                                                "start", current.toString(),
                                                "end", bookingStart.toString(),
                                                "status", "FREE"));
                        }

                        // Booked slot
                        slots.add(Map.of(
                                        "start", bookingStart.toString(),
                                        "end", bookingEnd.toString(),
                                        "status", "BOOKED",
                                        "event", b.getEvent_title(),
                                        "hall", b.getHall().getName()));

                        current = bookingEnd;
                }

                // Remaining free slot
                if (current.isBefore(endDay)) {
                        slots.add(Map.of(
                                        "start", current.toString(),
                                        "end", endDay.toString(),
                                        "status", "FREE"));
                }

                return slots;
        }

        public List<Map<String, Object>> getMonthlyView(int year, int month) {

                // 1️⃣ Get start and end of month
                LocalDate startDate = LocalDate.of(year, month, 1);
                LocalDate endDate = startDate.withDayOfMonth(startDate.lengthOfMonth());

                LocalDateTime start = startDate.atStartOfDay();
                LocalDateTime end = endDate.atTime(23, 59);

                // 2️⃣ Fetch bookings
                List<Booking> bookings = bookingRepository.findByStartTimeBetween(start, end)
                                .stream()
                                .filter(b -> b.getStatus() == Booking.Status.APPROVED)
                                .collect(Collectors.toList());

                List<Map<String, Object>> result = new ArrayList<>();

                bookings.sort(Comparator.comparing(Booking::getStartTime));

                // 3️⃣ Transform data
                for (Booking b : bookings) {

                        Map<String, Object> map = new HashMap<>();

                        String name;
                        String phone;

                        String studentName = b.getUser().getFull_name();
                        String coordinatorName = b.getCoordinatorName();

                        String studentPhone = b.getUser() != null ? b.getUser().getPhone() : null;
                        String coordinatorPhone = b.getCoordinatorPhone();

                        // 🔥 Name formatting
                        if (b.getUser().getRole() == User.Role.STUDENT) {
                                if (coordinatorName != null && !coordinatorName.isBlank()) {
                                        name = studentName + " / " + coordinatorName;
                                } else {
                                        name = studentName;
                                }

                                if (coordinatorPhone != null && !coordinatorPhone.isBlank()) {
                                        phone = studentPhone + " / " + coordinatorPhone;
                                } else {
                                        phone = studentPhone;
                                }

                        } else {
                                name = studentName;
                                phone = studentPhone;
                        }

                        map.put("date", b.getStartTime().toLocalDate().toString());
                        map.put("name", name);
                        map.put("hall", b.getHall() != null ? b.getHall().getName() : "—");
                        map.put("time", b.getStartTime().toLocalTime() + " → " + b.getEndTime().toLocalTime());
                        map.put("phone", phone != null && !phone.isBlank() ? phone : "—");
                        map.put("event", b.getEvent_title() != null ? b.getEvent_title() : "—");
                        map.put("eventType", b.getEvent_type() != null ? b.getEvent_type() : "—");

                        System.out.println(" ");
                        System.out.println(" ");
                        System.out.println("Processing booking: ");
                        System.out.println(" ");
                        System.out.println(" ");

                        result.add(map);
                }

                return result;
        }

        public Map<String, Object> getUserStats(String email) {

                User user = userRepository.findByEmail(email)
                                .orElseThrow(() -> new RuntimeException("User not found"));

                List<Booking> bookings = bookingRepository.findByUserOrderByCreatedAtDesc(user);

                long total = bookings.size();

                long accepted = bookings.stream()
                                .filter(b -> b.getStatus() == Booking.Status.APPROVED)
                                .count();

                long pending = bookings.stream()
                                .filter(b -> b.getStatus() == Booking.Status.PENDING)
                                .count();

                long rejected = bookings.stream()
                                .filter(b -> b.getStatus() == Booking.Status.REJECTED)
                                .count();

                long cancelled = bookings.stream()
                                .filter(b -> b.getStatus() == Booking.Status.CANCELLED)
                                .count();

                return Map.of(
                                "totalBookings", total,
                                "accepted", accepted,
                                "pending", pending,
                                "rejected", rejected,
                                "cancelled", cancelled);
        }
}