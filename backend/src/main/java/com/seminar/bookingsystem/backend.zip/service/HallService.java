package com.seminar.bookingsystem.service;

import org.springframework.stereotype.Service;
import java.util.List;

import com.seminar.bookingsystem.repository.HallsRepository;
import com.seminar.bookingsystem.dto.HallRequest;
import com.seminar.bookingsystem.dto.HallResponse;
import com.seminar.bookingsystem.model.Hall;

@Service
public class HallService {

    private final HallsRepository hallsRepository;

    public HallService(HallsRepository hallsRepository) {
        this.hallsRepository = hallsRepository;
    }

    public Hall AddHall(HallRequest request) {
        if (hallsRepository.findByName(request.getName()).isPresent()) {
            throw new RuntimeException("Hall already exists with this name");
        }
        Hall hall = new Hall();
        hall.setName(request.getName());
        hall.setCapacity(request.getCapacity());
        hall.setLocation(request.getLocation());
        // Convert List<String> to comma-separated String
        hall.setAmenities(request.getAmenities() != null ? String.join(",", request.getAmenities()) : null);
        hall.setImageUrls(request.getImageUrls() != null ? String.join(",", request.getImageUrls()) : null);
        return hallsRepository.save(hall);
    }

    // 🔥 FETCH ALL HALLS
    public List<HallResponse> getAllHalls() {
        List<Hall> halls = hallsRepository.findAll();
        return halls.stream().map(hall -> {
            HallResponse response = new HallResponse();
            response.setId(hall.getId());
            response.setName(hall.getName());
            response.setCapacity(hall.getCapacity());
            response.setLocation(hall.getLocation());
            // Convert comma-separated String to List<String>
            response.setAmenities(hall.getAmenities() != null && !hall.getAmenities().isEmpty()
                ? List.of(hall.getAmenities().split(",")) : List.of());
            response.setImageUrls(hall.getImageUrls() != null && !hall.getImageUrls().isEmpty()
                ? List.of(hall.getImageUrls().split(",")) : List.of());
            response.setActive(hall.isActive());
            return response;
        }).toList();
    }

    public Hall toggleHall(Long id) {
        Hall hall = hallsRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Hall not found"));
        hall.setActive(!hall.isActive());
        return hallsRepository.save(hall);
    }

}
