package com.seminar.bookingsystem.dto;

import  lombok.Data;
import java.util.List;

@Data
public class HallRequest {

    private String name;
    private int capacity;
    private String location;
    private List<String> amenities;
    private List<String> imageUrls;
    private boolean isActive;
}