package com.seminar.bookingsystem.controller;

import org.springframework.web.bind.annotation.*;
import java.util.List;

import com.seminar.bookingsystem.dto.HallRequest;
import com.seminar.bookingsystem.dto.HallResponse;
import com.seminar.bookingsystem.model.Hall;
import com.seminar.bookingsystem.service.HallService;

@RestController
@RequestMapping("/halls")
@CrossOrigin(origins = "http://localhost:3000")
public class HallController {

    private final HallService hallService;

    public HallController(HallService hallService) {
        this.hallService = hallService;
    }

    @GetMapping
    public List<HallResponse> getAllHalls() {

        System.out.println("🔥 Controller hit");

        return hallService.getAllHalls();
    }

    @PostMapping
    public Hall AddHall(@RequestBody HallRequest request) {
        return hallService.AddHall(request);
    }

    @PutMapping("/{id}/toggle")
    public Hall toggleHall(@PathVariable Long id) {
        return hallService.toggleHall(id);
    }
}