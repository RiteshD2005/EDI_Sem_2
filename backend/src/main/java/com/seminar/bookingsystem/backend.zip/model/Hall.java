package com.seminar.bookingsystem.model;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Data
@Table(name = "halls")
public class Hall {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "hall_id")
    private Long id;

    private String name;

    private int capacity;

    private String location;

    @Column(name = "amenities")
    private String amenities; // comma-separated

    @Column(name = "image_urls")
    private String imageUrls; // comma-separated

    @Column(name = "is_active")
    private boolean isActive = true;

    @Column(name = "created_at")
    private LocalDateTime createdAt = LocalDateTime.now();
}