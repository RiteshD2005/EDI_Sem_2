package com.seminar.bookingsystem.controller;

import org.springframework.web.bind.annotation.*;
import java.util.List;

import com.seminar.bookingsystem.dto.HallRequest;
import com.seminar.bookingsystem.dto.HallResponse;
import com.seminar.bookingsystem.model.Hall;
import com.seminar.bookingsystem.service.HallService;

@RestController
@RequestMapping("/admin/halls")
@CrossOrigin(origins = "http://localhost:3000")
public class AdminHallController {

    private final HallService hallService;

    public AdminHallController(HallService hallService) {
        this.hallService = hallService;
    }

    // 🔥 GET ALL HALLS
    @GetMapping
    public List<HallResponse> getAllHalls() {
        return hallService.getAllHalls();
    }

    @PostMapping("/addhall")
    public Hall addHall(@RequestBody HallRequest request) {
        return hallService.AddHall(request);
    }

    // 🔥 TOGGLE ACTIVE/INACTIVE
    @PutMapping("/{id}/toggle")
    public Hall toggleHall(@PathVariable Long id) {
        return hallService.toggleHall(id);
    }
}