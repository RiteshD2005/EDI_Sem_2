"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { ArrowLeft, Calendar, MapPin, Clock, AlertCircle, Loader2 } from "lucide-react";

type Hall = {
  id: number;
  name: string;
  location?: string;
};

type Slot = {
  start: string;
  end: string;
  status: "FREE" | "BOOKED";
  event?: string;
  hall?: string;
};

export default function CheckSlotPage() {
  const router = useRouter();
  const [halls, setHalls] = useState<Hall[]>([]);
  const [hallId, setHallId] = useState("");
  const [date, setDate] = useState("");
  const [slots, setSlots] = useState<Slot[]>([]);
  const [loadingSlots, setLoadingSlots] = useState(false);
  const [error, setError] = useState("");

  const token = typeof window !== "undefined" ? localStorage.getItem("token") : null;

  // Fetch halls on mount
  useEffect(() => {
    fetch("http://localhost:8080/halls")
      .then((res) => res.json())
      .then(setHalls)
      .catch(console.error);
  }, []);

  const fetchSlots = async () => {
    if (!hallId || !date) {
      setError("Please select both a hall and a date.");
      return;
    }
    setError("");
    setLoadingSlots(true);
    try {
      const res = await fetch(
        `http://localhost:8080/booking/slots?hallId=${hallId}&date=${date}`,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      const text = await res.text();
      console.log("Raw response:", text);
      if (!res.ok) {
        throw new Error(text || "Failed to fetch slots");
      }
      const data = text ? JSON.parse(text) : [];
      setSlots(Array.isArray(data) ? data : []);
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Something went wrong");
      setSlots([]);
    } finally {
      setLoadingSlots(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 py-8">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Back Button */}
        <button
          onClick={() => router.push("/home")}
          className="mb-4 inline-flex items-center gap-2 text-sm text-gray-600 hover:text-indigo-600 transition"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Home
        </button>

        {/* Header */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold tracking-tight text-gray-900">
            Check Hall Availability
          </h1>
          <p className="text-sm text-gray-500 mt-1">
            Select a hall and date to view available time slots
          </p>
        </div>

        {/* Filter Card */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6 mb-8">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <label className="block text-xs font-medium text-gray-500 mb-1">Hall</label>
              <select
                value={hallId}
                onChange={(e) => setHallId(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
              >
                <option value="">Select a hall</option>
                {halls.map((hall) => (
                  <option key={hall.id} value={hall.id}>
                    {hall.name} {hall.location ? `(${hall.location})` : ""}
                  </option>
                ))}
              </select>
            </div>
            <div className="flex-1">
              <label className="block text-xs font-medium text-gray-500 mb-1">Date</label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:border-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-500"
              />
            </div>
            <div className="flex items-end">
              <button
                onClick={fetchSlots}
                disabled={!hallId || !date || loadingSlots}
                className="bg-indigo-600 text-white px-5 py-2 rounded-lg text-sm font-medium hover:bg-indigo-700 transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
              >
                {loadingSlots && <Loader2 className="h-4 w-4 animate-spin" />}
                {loadingSlots ? "Checking..." : "Check Slots"}
              </button>
            </div>
          </div>
          {error && (
            <div className="mt-4 flex items-center gap-2 text-sm text-red-600 bg-red-50 p-3 rounded-lg">
              <AlertCircle className="h-4 w-4" />
              {error}
            </div>
          )}
        </div>

        {/* Slots Table */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="px-5 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">#</th>
                  <th className="px-5 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Time Slot</th>
                  <th className="px-5 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                  <th className="px-5 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Event</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {slots.map((slot, idx) => (
                  <tr key={`${slot.start}-${slot.end}-${idx}`} className="hover:bg-gray-50">
                    <td className="px-5 py-3 text-gray-500">{idx + 1}</td>
                    <td className="px-5 py-3 font-medium text-gray-900">
                      {slot.start} → {slot.end}
                    </td>
                    <td className="px-5 py-3">
                      <span
                        className={`inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-medium ${
                          slot.status === "BOOKED"
                            ? "bg-red-100 text-red-800"
                            : "bg-green-100 text-green-800"
                        }`}
                      >
                        {slot.status === "BOOKED" ? "Booked" : "Available"}
                      </span>
                    </td>
                    <td className="px-5 py-3 text-gray-600">{slot.event || "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {!loadingSlots && slots.length === 0 && !error && (
            <div className="text-center py-8 text-gray-500">
              <Calendar className="h-8 w-8 mx-auto mb-2 text-gray-400" />
              <p>No slots to display. Please select a hall and date.</p>
            </div>
          )}
          {loadingSlots && (
            <div className="flex justify-center py-8">
              <Loader2 className="h-6 w-6 animate-spin text-indigo-600" />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}